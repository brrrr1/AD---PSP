package com.example.monumentosv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Monumentosv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Monumentosv2Application.class, args);
	}

}
