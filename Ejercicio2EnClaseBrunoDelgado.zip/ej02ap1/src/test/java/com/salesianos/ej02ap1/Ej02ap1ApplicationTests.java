package com.salesianos.ej02ap1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej02ap1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
