package com.salesianos.ej02ap1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej02ap1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej02ap1Application.class, args);
	}

}
