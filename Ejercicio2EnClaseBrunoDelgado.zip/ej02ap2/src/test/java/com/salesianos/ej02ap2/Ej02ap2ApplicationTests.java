package com.salesianos.ej02ap2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej02ap2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
