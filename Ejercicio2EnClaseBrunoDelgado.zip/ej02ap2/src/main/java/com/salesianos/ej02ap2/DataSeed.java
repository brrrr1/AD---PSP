package com.salesianos.ej02ap2;

public class DataSeed {
}
